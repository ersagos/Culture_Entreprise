#!/bin/bash

#apt-get update
#apt-get install -y make
#apt-get install -y gcc
cd /src/dist
java -jar ConsoleAvion.jar

