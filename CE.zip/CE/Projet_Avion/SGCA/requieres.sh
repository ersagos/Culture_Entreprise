#!/bin/bash

#apt-get update
#apt-get install -y make
#apt-get install -y gcc
cd /src/SGCA
make
./SGCA.out
