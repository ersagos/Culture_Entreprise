#ifndef SGCA_H
#define SGCA_H
#define PATHNAME "file.ftok"
#define PROJ_ID 1
#endif
